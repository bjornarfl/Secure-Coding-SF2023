# Secure Coding Practice
 A sample web application containing vulnerabilities from OWASP Top 10. All information in this repository is entirely fictional.

# How to run locally
 1. Install Python >3.7
 2. Create and activate a virtual environment
 3. Navigate to the base folder (containing the manage.py file)
 4. install the requirements in requirements.txt using `pip install -r requirements.txt`
 5. `python manage.py runserver`
 6. The application will be hosted at `localhost:8000`
 7. To stop the server from running press Ctrl+C in the terminal

 The database is preloaded with the dummy-data that can be found in dump.json.
 If you have made changes in the data and want to revert back to the original state, you can do the following:
 1. Activate your virtual environment
 2. Navigate to the base folder (containing the manage.py file)
 3. `python manage.py flush`
 4. `python manage.py loaddata dump.json`