from django.apps import AppConfig


class BaasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'BaaS'
